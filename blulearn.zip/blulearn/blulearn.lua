addon.name    = 'blulearn'
addon.author  = 'Strafeous'
addon.version = '1.1'
addon.desc    = 'Shows which Blue Magic spell your target teaches while Shift is held.'
addon.link    = ''

require('common')
local imgui = require('imgui')
local ffi   = require('ffi')

local JOB_BLU = 16
local debug_on = false
local always_on = false
local last_err = ''

-- Shift detection: Windows key state, with ImGui as a backup
pcall(ffi.cdef, [[ short GetAsyncKeyState(int vKey); ]])

local function shift_down()
    local ok, state = pcall(function() return ffi.C.GetAsyncKeyState(0x10) end)
    if ok and state ~= nil and bit.band(state, 0x8000) ~= 0 then return true end
    local ok2, io_shift = pcall(function() return imgui.GetIO().KeyShift end)
    if ok2 and io_shift == true then return true end
    return false
end

-- Family data: a mob's family is guessed from keywords in its name (see blu_data.lua)
local families = require('blu_data')
local cache = {}

local function contains_any(key, words)
    for _, w in ipairs(words) do
        if key:find(w, 1, true) then return true end
    end
    return false
end

local function find_spells(name)
    local key = name:lower()
    if cache[key] ~= nil then return cache[key] end
    local out = {}
    for _, fam in ipairs(families) do
        if contains_any(key, fam.match) and not (fam.exclude and contains_any(key, fam.exclude)) then
            for _, s in ipairs(fam.spells) do
                table.insert(out, { spell = s[1], level = s[2], family = fam.family })
            end
        end
    end
    cache[key] = out
    return out
end

local function get_target_name()
    local mem = AshitaCore:GetMemoryManager()
    local target = mem:GetTarget()
    if target == nil then return nil end

    local sub = target:GetIsSubTargetActive()
    local slot = (sub == true or sub == 1) and 1 or 0
    local idx = target:GetTargetIndex(slot)
    if idx == nil or idx == 0 then return nil end

    local name = mem:GetEntity():GetName(idx)
    if name == nil or name == '' then return nil end
    return name
end

-- Every blue magic spell level 1-75 (in level order), used by /blul list
local all_spells = {
    {'Sandspin',1},{'Pollen',1},{'Foot Kick',1},
    {'Power Attack',4},{'Sprout Smack',4},{'Wild Oats',4},
    {'Metallic Body',8},{'Cocoon',8},{'Queasyshroom',8},
    {'Battle Dance',12},{'Head Butt',12},{'Feather Storm',12},
    {'Helldive',16},{'Healing Breeze',16},{'Sheep Song',16},
    {'Bludgeon',18},{'Cursed Sphere',18},{'Blastbomb',18},
    {'Blood Drain',20},{'Claw Cyclone',20},
    {'Poison Breath',22},{'Soporific',24},{'Screwdriver',26},{'Bomb Toss',28},
    {'Wild Carrot',30},{'Grand Slam',30},
    {'Sound Blast',32},{'Chaotic Eye',32},
    {'Death Ray',34},{'Smite of Rage',34},
    {'Digest',36},{'Pinecone Bomb',36},
    {'Blank Gaze',38},{'Jet Stream',38},{'Uppercut',38},
    {'Mysterious Light',40},{'Terror Touch',40},
    {'Venom Shell',42},{'MP Drainkiss',42},
    {'Blitzstrahl',44},{'Stinking Gas',44},{'Mandibular Bite',44},
    {'Magnetite Cloud',46},{'Geist Wall',46},{'Awful Eye',46},
    {'Refueling',48},{'Blood Saber',48},{'Sickle Slash',48},{'Jettatura',48},
    {'Ice Break',50},{'Self-Destruct',50},{'Frightful Roar',50},
    {'Cold Wave',52},{'Filamented Hold',52},
    {'Hecatomb Wave',54},{'Radiant Breath',54},
    {'Feather Barrier',56},
    {'Magic Fruit',58},{'Flying Hip Press',58},{'Light of Penance',58},
    {'Death Scissors',60},{'Dimensional Death',60},{'Spiral Spin',60},
    {'Maelstrom',61},{'Eyes On Me',61},{'Seedspray',61},{'Bad Breath',61},
    {'Memento Mori',62},{'Body Slam',62},{'1000 Needles',62},
    {'Spinal Cleave',63},{'Frenetic Rip',63},{'Frypan',63},{'Hydro Shot',63},
    {'Feather Tickle',64},{'Yawn',64},{'Voracious Trunk',64},
    {'Infrasonics',65},{'Zephyr Mantle',65},
    {'Frost Breath',66},{'Sandspray',66},{'Corrosive Ooze',66},
    {'Diamondhide',67},{'Enervation',67},
    {'Warm-Up',68},{'Firespit',68},
    {'Tail Slap',69},{'Hysteric Barrage',69},{'Regurgitation',69},
    {'Amplification',70},{'Cannonball',70},{'Asuran Claws',70},
    {'Lowing',71},{'Heat Breath',71},{'Triumphant Roar',71},
    {'Disseverment',72},{'Sub-zero Smash',72},{'Saline Coat',72},
    {'Ram Charge',73},{'Mind Blast',73},{'Temporal Shift',73},
    {'Actinic Burst',74},{'Magic Hammer',74},{'Reactor Cool',74},
    {'Exuviation',75},{'Plasma Charge',75},{'Vertical Cleave',75},
}

-- true / false if we can tell whether you know the spell, nil if we can't look it up
local function is_known(spell_name)
    local ok, res = pcall(function()
        local spell = AshitaCore:GetResourceManager():GetSpellByName(spell_name, 0)
        if spell == nil then return nil end
        return AshitaCore:GetMemoryManager():GetPlayer():HasSpell(spell.Index)
    end)
    if ok then return res end
    return nil
end

-- Spell name -> family that teaches it (from blu_data.lua)
local spell_family = {}
for _, fam in ipairs(families) do
    for _, sp in ipairs(fam.spells) do
        local cur = spell_family[sp[1]]
        spell_family[sp[1]] = cur and (cur .. ', ' .. fam.family) or fam.family
    end
end

-- Unlearned-spell window (opened with /blul list)
local list_open = { false }
local list_data = { order = {}, by_level = {}, count = 0, unknown = 0 }

local function build_unlearned()
    local d = { order = {}, by_level = {}, count = 0, unknown = 0 }
    for _, s in ipairs(all_spells) do
        local known = is_known(s[1])
        if known == nil then
            d.unknown = d.unknown + 1
        elseif known == false then
            if d.by_level[s[2]] == nil then
                d.by_level[s[2]] = {}
                table.insert(d.order, s[2])
            end
            table.insert(d.by_level[s[2]], s[1])
            d.count = d.count + 1
        end
    end
    list_data = d
end

local function draw_list_window()
    if not list_open[1] then return end

    imgui.SetNextWindowSize({ 380, 460 }, ImGuiCond_FirstUseEver)
    imgui.SetNextWindowPos({ 300, 150 }, ImGuiCond_FirstUseEver)
    if imgui.Begin('BluLearn - Unlearned Spells (Lv 1-75)', list_open) then
        imgui.Text(('%d spells not learned yet'):fmt(list_data.count))
        imgui.SameLine()
        if imgui.Button('Refresh') then build_unlearned() end
        imgui.Separator()

        if list_data.count == 0 then
            imgui.Text('Nothing left to learn!')
        end
        for _, lvl in ipairs(list_data.order) do
            imgui.TextColored({ 1.0, 0.85, 0.3, 1.0 }, ('Lv %d'):fmt(lvl))
            for _, name in ipairs(list_data.by_level[lvl]) do
                imgui.Text('    ' .. name)
                local fam = spell_family[name]
                imgui.SameLine()
                if fam then
                    imgui.TextColored({ 0.6, 0.85, 1.0, 1.0 }, '- ' .. fam)
                else
                    imgui.TextColored({ 0.5, 0.5, 0.5, 1.0 }, '- family not listed')
                end
            end
        end

        if list_data.unknown > 0 then
            imgui.Separator()
            imgui.Text(('%d spell(s) could not be checked.'):fmt(list_data.unknown))
        end
    end
    imgui.End()
end

local flags = bit.bor(
    ImGuiWindowFlags_NoDecoration,
    ImGuiWindowFlags_AlwaysAutoResize,
    ImGuiWindowFlags_NoFocusOnAppearing,
    ImGuiWindowFlags_NoNav
)

local function draw()
    local player = AshitaCore:GetMemoryManager():GetPlayer()
    local main_job = player and player:GetMainJob() or -1
    local sub_job  = player and player:GetSubJob() or -1
    local shift    = shift_down()
    local name     = get_target_name()
    local list     = name and find_spells(name) or {}
    local is_blu   = (main_job == JOB_BLU or sub_job == JOB_BLU)

    if debug_on then
        imgui.SetNextWindowBgAlpha(0.9)
        imgui.SetNextWindowPos({ 600, 300 }, ImGuiCond_FirstUseEver)
        if imgui.Begin('BluLearn Debug', true, ImGuiWindowFlags_AlwaysAutoResize) then
            imgui.Text(('Main job id: %s   Sub job id: %s   (BLU = 16)'):fmt(tostring(main_job), tostring(sub_job)))
            imgui.Text(('Shift held: %s'):fmt(tostring(shift)))
            imgui.Text(('Target name: %s'):fmt(tostring(name)))
            imgui.Text(('Matches found: %d'):fmt(#list))
            if last_err ~= '' then imgui.Text('ERROR: ' .. last_err) end
        end
        imgui.End()
    end

    if (not shift and not always_on) or #list == 0 then return end

    imgui.SetNextWindowBgAlpha(0.85)
    imgui.SetNextWindowPos({ 600, 120 }, ImGuiCond_FirstUseEver) -- drag it wherever you like
    if imgui.Begin('BluLearn', true, flags) then
        for _, e in ipairs(list) do
            imgui.Text(("%s's teach %s - Level %d"):fmt(e.family, e.spell, e.level))
        end
    end
    imgui.End()
end

ashita.events.register('d3d_present', 'blulearn_present', function()
    local ok, err = pcall(draw)
    if not ok then last_err = tostring(err) end
    local ok2, err2 = pcall(draw_list_window)
    if not ok2 then last_err = tostring(err2) end
end)

local function print_help()
    print('[blulearn] Hold Shift while targeting a mob to see what blue magic its family teaches.')
    print('  /blul list    - open/close a window of the spells (Lv 1-75) you have not learned')
    print('  /blul always  - show the target box without holding Shift (toggle)')
    print('  /blul debug   - show a diagnostics box (toggle)')
    print('  /blul help    - show this list')
end

ashita.events.register('command', 'blulearn_command', function(e)
    local args = e.command:args()
    if #args == 0 then return end
    local cmd = args[1]:lower()
    if cmd ~= '/blul' and cmd ~= '/blulearn' then return end
    e.blocked = true

    local sub = args[2] and args[2]:lower() or ''
    if sub == 'list' then
        if list_open[1] then
            list_open[1] = false
        else
            build_unlearned()
            list_open[1] = true
        end
    elseif sub == 'debug' then
        debug_on = not debug_on
        print('[blulearn] debug ' .. (debug_on and 'on' or 'off'))
    elseif sub == 'always' then
        always_on = not always_on
        print('[blulearn] show without Shift: ' .. (always_on and 'on' or 'off'))
    else
        print_help()
    end
end)

print('[blulearn] loaded. Type /blul help for commands.')
